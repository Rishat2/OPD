#!/bin/sh
# The installation script of PSCyr package for teTeX-2.0.  For other
# systems see details in README.* files.
#
# Archive is downloaded from
# https://github.com/AndreyAkinshin/Russian-Phd-LaTeX-Dissertation-Template/blob/master/PSCyr/pscyr0.4d.zip
# but its structure and pscyr.map file are modified according to
# http://welinux.ru/post/3200/ 
# see https://lisakov.com/blog/pscyr/ (Russian)

kpsewhich -expand-var='$TEXMFLOCAL'
sudo cp -R * $TEXMFLOCAL
sudo texhash
updmap --enable Map=pscyr.map
sudo mktexlsr
